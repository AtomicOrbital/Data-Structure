#include<iostream>
#include<string>
#include<vector>
#include<math.h>

using namespace std;
vector<int> x;
int mod=1e9+7;
void prepare()
{
    f1
}
int main()
{
    int T;

	return 0;
}
