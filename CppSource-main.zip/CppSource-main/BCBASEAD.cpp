#include<iostream>
#include<string>
#include<vector>
#include<math.h>

using namespace std;

int main()
{

	return 0;
}
