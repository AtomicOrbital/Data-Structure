#include<bits/stdc++.h>
#include"Nguoi.h"
using namespace std;
int main()
{
    Nguoi * nguoi = new Nguoi();
    nguoi->eat();
    return 0;
}