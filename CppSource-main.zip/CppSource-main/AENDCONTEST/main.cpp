#include <iostream>

using namespace std;

int main()
{
    unsigned long long a,b;
    cin>>a>>b;
    cout<<a+b<<' '<<a*b<<' '<<b-a;
    return 0;
}
