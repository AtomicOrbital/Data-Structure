#pragma once
#include<bits/stdc++.h>

using namespace std;

class Sach
{
    private:
        int id;
        string name, author, major, year;
          
};