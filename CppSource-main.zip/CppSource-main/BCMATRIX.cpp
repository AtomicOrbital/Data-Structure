#include<iostream>
#include<string>
#include<vector>
#include<math.h>

using namespace std;

int main()
{
    int n;
    cin>>n;
    for(int m=1;m<=n;m++)
    {
        int tmp[m][m]={};
        for(int i=1;i<=m;i++)
            for(int j=1;j<=m;j++)
            {
                tmp[i][j]=
            }
	return 0;
}
