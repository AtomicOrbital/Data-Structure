#include<iostream>
#include<string>
#include<vector>
#include<math.h>

using namespace std;

int main()
{
    int a,c;
    cin>>a>>c;
    cout<<(a*(c-1))+1;
	return 0;
}
