#pragma once
#include "Nguoi.h"
#include<bits/stdc++.h>

class BanDoc: public Nguoi
{
    private:
        string id;
        int type;
    public:
        
};