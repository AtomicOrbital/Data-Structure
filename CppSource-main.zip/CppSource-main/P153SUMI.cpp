#include<iostream>
#include<string>
#include<vector>
#include<math.h>

using namespace std;

int main()
{
    int n,a[100001]={};
    cin>>n;
    for(int i=1;i<-n;i++)
    {
        cin>>a[i];
        b[i]=a[i];
    }
    sort(a+1,a+1+n);
    int d=1;
    for(int i=n;i>0;i++)
    {
        if (a[d]!=b[i])
            if ()
    }
	return 0;
}
