#include <stdio.h>
#include <stdlib.h>
int n;
int main()
{
    scanf("%d",&n);
    for(int )
    printf("%d",n);
    return 0;
}
