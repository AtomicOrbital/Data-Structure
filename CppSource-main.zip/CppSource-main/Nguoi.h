#pragma once
#include<bits/stdc++.h>
using namespace std;

class Nguoi
{
    private:
        string id, name;
    public:
        
};