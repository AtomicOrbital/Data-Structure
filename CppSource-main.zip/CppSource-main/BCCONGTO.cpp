#include<iostream>
#include<string>
#include<vector>
#include<math.h>

using namespace std;

int main()
{
    for(int i=1;i<=999999999;i++)
        if (kt(i))
	return 0;
}
